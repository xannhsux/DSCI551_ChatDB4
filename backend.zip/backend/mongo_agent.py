from pymongo import MongoClient

MONGO_URI = "mongodb+srv://flightsdata:dsci551@flightsdata.y57hp.mongodb.net/?retryWrites=true&w=majority"

client = MongoClient(MONGO_URI)
db = client["flights"]
collection = db["DSCI551_Project"]

def get_all_flights():
    return list(collection.find({}, {"_id": 0}))

def get_flights_by_airports(starting, destination):
    return list(collection.find({
        "startingAirport": starting,
        "destinationAirport": destination
    }, {"_id": 0}))

def get_flights_by_airline(airline_name):
    return list(collection.find({
        "segmentsAirlineName": airline_name
    }, {"_id": 0}))
