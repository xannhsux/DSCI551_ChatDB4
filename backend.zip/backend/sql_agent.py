import sqlite3
import os
import logging

# 假设在 Dockerfile 或运行环境中, hotel.db 跟 python脚本在同一目录
SQLITE_DB_PATH = os.path.join(os.getcwd(), "hotel.db")

def get_connection():
    """返回与 SQLite 数据库的连接"""
    return sqlite3.connect(SQLITE_DB_PATH)

def execute_sql_query(query, params=()):
    """
    执行 SQL 查询，并返回所有结果
    :param query: SQL 查询语句
    :param params: 查询参数（元组形式）
    :return: 查询结果列表
    """
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(query, params)
        results = cursor.fetchall()
        conn.commit()
    except Exception as e:
        logging.error("Error executing query: %s", e)
        results = None
    finally:
        conn.close()
    return results

def get_all_reviews():
    """
    获取 hotel_reviews 表中所有记录
    """
    query = "SELECT * FROM hotel_reviews;"
    return execute_sql_query(query)

def get_reviews_by_county(county):
    """
    根据 county 查询 hotel_reviews 表中的记录
    """
    query = "SELECT * FROM hotel_reviews WHERE county = ?;"
    return execute_sql_query(query, (county,))

def get_reviews_by_state(state):
    """
    根据 state 查询 hotel_reviews 表中的记录
    """
    query = "SELECT * FROM hotel_reviews WHERE state = ?;"
    return execute_sql_query(query, (state,))

def insert_review(rating, sleepquality, service, rooms, cleanliness, value, hotel_name, county, state):
    """
    向 hotel_reviews 表中插入一条新的记录, 返回新插入行的 rowid
    """
    query = """
    INSERT INTO hotel_reviews
    (rating, sleepquality, service, rooms, cleanliness, value, hotel_name, county, state)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);
    """
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(query, (rating, sleepquality, service, rooms, cleanliness, value, hotel_name, county, state))
        conn.commit()
        result = cursor.lastrowid
    except Exception as e:
        logging.error("Error inserting review: %s", e)
        result = None
    finally:
        conn.close()
    return result

def update_review_rating(row_id, new_rating):
    """
    更新指定 rowid 记录的 rating
    """
    query = "UPDATE hotel_reviews SET rating = ? WHERE rowid = ?;"
    return execute_sql_query(query, (new_rating, row_id))

def delete_review(row_id):
    """
    删除指定 rowid 记录
    """
    query = "DELETE FROM hotel_reviews WHERE rowid = ?;"
    return execute_sql_query(query, (row_id,))

# 测试代码 (可在终端运行: python sql_agent.py)
if __name__ == "__main__":
    print("All reviews:", get_all_reviews())

    # 插入演示数据
    new_id = insert_review(
        rating=5.0,
        sleepquality="4.5",
        service="5.0",
        rooms="4.0",
        cleanliness="5.0",
        value="4.0",
        hotel_name="Test Hotel",
        county="SampleCounty",
        state="SampleState"
    )
    print("Inserted new record ID:", new_id)

    # 查询插入后的记录
    inserted = get_reviews_by_county("SampleCounty")
    print("Reviews in SampleCounty:", inserted)

    # 更新 rating
    update_review_rating(new_id, 3.5)
    updated = get_reviews_by_county("SampleCounty")
    print("Updated record(s) in SampleCounty:", updated)

    # 删除该测试记录
    delete_review(new_id)
    after_delete = get_reviews_by_county("SampleCounty")
    print("After delete, reviews in SampleCounty:", after_delete)
